package com.apip.alfa.fragmentsShowrActivity

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.apip.alfa.R


class SupportFragment : Fragment() {

    private lateinit var backBtn: ImageView



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val Root = inflater.inflate(R.layout.fragment_support, container, false)

        backBtn = Root.findViewById(R.id.back_support_btn)

        backBtn.setOnClickListener {

            requireActivity().finish()

        }

        return Root
    }

}