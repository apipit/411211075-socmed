package com.apip.alfa.adapterClasses

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.apip.alfa.R
import com.google.android.material.imageview.ShapeableImageView

class AdapterRecyclerviewStories(private var listOfData: List<String>)
    : RecyclerView.Adapter<StoriesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoriesViewHolder {
        // Create and return a new ViewHolder
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_stories, parent, false)
        return StoriesViewHolder(view)
    }

    override fun getItemCount(): Int {

        return listOfData.size

    }

    override fun onBindViewHolder(holder: StoriesViewHolder, position: Int) {

        //holder.imageStories.setImageResource(R.drawable.logo)

    }
}

class StoriesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

    val imageStories : ShapeableImageView = itemView.findViewById(R.id.imageStories)

}