package com.apip.alfa.dataClasses

data class UserId(
    var name : String? = null,
    var id : String? = null,
    var imgAccount : String? = null,
    var imageBackUrl : String? = null,
    var userName : String? = null
)
